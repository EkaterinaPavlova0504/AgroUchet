﻿#pragma once
#include "Theme.h"
#include "Database.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Drawing;

namespace AgroUchet {

    public ref class ZootechnikDashboard {
    private:
        Form^ form;
        DataGridView^ dgvAnimals;

    public:
        ZootechnikDashboard(Form^ parentForm) {
            form = parentForm;
        }

        void Show() {
            form->Controls->Clear();
            form->BackColor = Theme::Bg;

            CreateHeader();

            // Быстрые действия
            Panel^ actionsPanel = UIHelper::CreateCard(25, 75, 420, 380);
            actionsPanel->Controls->Add(UIHelper::CreateLabel(L"Быстрые действия", 18, 15, 16, Theme::Text, FontStyle::Bold));

            array<String^>^ actions = {
                L"🐄 Зафиксировать привес",
                L"🥛 Внести данные о надое",
                L"🌽 Списать корма по группе",
                L"💉 Зарегистрировать вет. событие",
                L"🔄 Переместить животное"
            };

            for (int i = 0; i < 5; i++) {
                Button^ actBtn = UIHelper::CreateButton(actions[i], 18, 55 + i * 55, 380, 42, Color::White, Theme::Text);
                actBtn->TextAlign = ContentAlignment::MiddleLeft;
                actBtn->FlatAppearance->BorderSize = 1;
                actBtn->FlatAppearance->BorderColor = Theme::Border;
                actBtn->FlatAppearance->MouseOverBackColor = Color::FromArgb(249, 250, 251);
                actBtn->Click += gcnew EventHandler(this, &ZootechnikDashboard::BtnActionClick);
                actionsPanel->Controls->Add(actBtn);
            }
            form->Controls->Add(actionsPanel);

            // KPI
            Panel^ kpiPanel = UIHelper::CreateCard(470, 75, 420, 180);
            kpiPanel->Controls->Add(UIHelper::CreateLabel(L"Текущие показатели", 18, 15, 16, Theme::Text, FontStyle::Bold));

            array<String^>^ kpiLabels = { L"Надой сегодня:", L"Средний привес:", L"Остаток комбикорма:", L"Поголовье КРС:" };
            array<String^>^ kpiValues = { L"487 л", L"0.8 кг/день", L"1 240 кг", Database::Animals->Count.ToString() };

            for (int i = 0; i < 4; i++) {
                kpiPanel->Controls->Add(UIHelper::CreateLabel(kpiLabels[i], 20, 48 + i * 30, 10, Theme::TextGray, FontStyle::Regular));
                Color valColor = (i == 2) ? Theme::Warning : Theme::Text;
                kpiPanel->Controls->Add(UIHelper::CreateLabel(kpiValues[i], 190, 48 + i * 30, 13, valColor, FontStyle::Bold));
            }
            form->Controls->Add(kpiPanel);

            // Напоминание
            Panel^ reminderPanel = gcnew Panel();
            reminderPanel->Size = Drawing::Size(420, 55);
            reminderPanel->Location = Point(470, 270);
            reminderPanel->BackColor = Theme::YellowBg;
            Label^ reminder = UIHelper::CreateLabel(L"📌 Завтра в 10:00 плановая вакцинация КРС в загоне №2", 12, 20, 9, Color::FromArgb(133, 77, 14), FontStyle::Bold);
            reminder->Size = Drawing::Size(395, 35);
            reminderPanel->Controls->Add(reminder);
            form->Controls->Add(reminderPanel);

            // Быстрый ввод надоя
            Panel^ quickPanel = UIHelper::CreateCard(470, 340, 420, 115);
            quickPanel->Controls->Add(UIHelper::CreateLabel(L"⚡ Быстрый ввод надоя", 18, 15, 12, Theme::Text, FontStyle::Bold));
            quickPanel->Controls->Add(UIHelper::CreateTextBox(L"Литров", 18, 45, 250, 38));
            quickPanel->Controls->Add(UIHelper::CreatePrimaryButton(L"Сохранить", 280, 45, 120, 38));
            form->Controls->Add(quickPanel);

        }

        void CreateHeader() {
            Panel^ header = UIHelper::CreateHeader(1050);
            header->Controls->Add(UIHelper::CreateLabel(L"👨‍🌾 Рабочий стол животновода", 20, 12, 16, Color::White, FontStyle::Bold));
            header->Controls->Add(UIHelper::CreateLabel(L"Модуль учёта животных и кормов", 58, 40, 9, Color::FromArgb(209, 250, 229), FontStyle::Regular));
            header->Controls->Add(UIHelper::CreateLabel(Database::CurrentUser->FullName + L" (Животновод)", 650, 18, 10, Color::White, FontStyle::Regular));

            Button^ btnLogout = UIHelper::CreateButton(L"Выйти", 920, 12, 90, 30, Color::FromArgb(0, 173, 90), Color::White);
            btnLogout->FlatAppearance->MouseOverBackColor = Color::FromArgb(0, 214, 111);
            btnLogout->Click += gcnew EventHandler(this, &ZootechnikDashboard::BtnLogoutClick);
            header->Controls->Add(btnLogout);

            form->Controls->Add(header);
        }

        void ShowAnimalsTable() {
            dgvAnimals = UIHelper::CreateTable(25, 475, 980, 190);
            dgvAnimals->Columns->Add(L"colInv", L"ИНВ. НОМЕР");
            dgvAnimals->Columns->Add(L"colType", L"ВИД");
            dgvAnimals->Columns->Add(L"colBreed", L"ПОРОДА");
            dgvAnimals->Columns->Add(L"colWeight", L"ВЕС (КГ)");
            dgvAnimals->Columns->Add(L"colBirth", L"ДАТА РОЖДЕНИЯ");
            dgvAnimals->Columns->Add(L"colHealth", L"СТАТУС");
            dgvAnimals->Columns->Add(L"colActions", L"ДЕЙСТВИЯ");

            for each (Animal ^ a in Database::Animals) {
                dgvAnimals->Rows->Add(a->InvNumber, a->Type, a->Breed, a->Weight.ToString("F0"),
                    a->BirthDate.ToString("dd.MM.yyyy"), a->HealthStatus, L"✏️  🗑️");
            }
            form->Controls->Add(dgvAnimals);
        }

        // События
        event EventHandler^ OnLogout;
        event EventHandler^ OnAnimalsManage;

        // Обработчики кнопок (обычные методы, не события!)
        void BtnLogoutClick(Object^ s, EventArgs^ e) {
            OnLogout(s, e);
        }

        void BtnActionClick(Object^ s, EventArgs^ e) {
            OnAnimalsManage(s, e);
        }
    };
}